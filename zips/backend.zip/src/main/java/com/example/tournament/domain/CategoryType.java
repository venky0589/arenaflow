package com.example.tournament.domain;

public enum CategoryType {
    SINGLES, DOUBLES
}
