package com.example.tournament.domain;

public enum MatchStatus {
    SCHEDULED, IN_PROGRESS, COMPLETED, WALKOVER, CANCELLED
}
