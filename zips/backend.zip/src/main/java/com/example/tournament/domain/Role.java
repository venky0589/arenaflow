package com.example.tournament.domain;

public enum Role {
    ADMIN, USER
}
