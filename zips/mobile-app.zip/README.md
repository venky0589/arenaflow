# Mobile App (Expo React Native)

## Prereqs
- Node 18+, `npm i -g expo-cli` (or use `npx expo`)
- Android Studio (emulator) or Expo Go on device

## Setup
1. Create `.env` or pass `EXPO_PUBLIC_API_BASE` at start:
   ```bash
   EXPO_PUBLIC_API_BASE=http://YOUR_BACKEND_HOST:8080 npm start
   ```
   - Android emulator to host: `http://10.0.2.2:8080` (default already set)
2. Install deps and run:
   ```bash
   npm i
   npm start
   ```

## Screens
- **Login** (JWT) → stores token in AsyncStorage
- **Tournaments** (list + quick register SINGLES)
- **Check-In** (local toggle; wire to API later)
- **Scoring** (increment scores for first match; simple PUT)

> This is a skeleton to unblock you; extend navigation, offline cache, and role-based access as needed.
