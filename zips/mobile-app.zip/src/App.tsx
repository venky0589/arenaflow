import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import Login from './screens/Login'
import CheckIn from './screens/CheckIn'
import Scoring from './screens/Scoring'
import Tournaments from './screens/Tournaments'

export type RootStackParamList = {
  Auth: undefined
  Main: undefined
  Scoring: { matchId: number } | undefined
}

const Stack = createNativeStackNavigator<RootStackParamList>()
const Tabs = createBottomTabNavigator()

function MainTabs() {
  return (
    <Tabs.Navigator>
      <Tabs.Screen name="Tournaments" component={Tournaments} />
      <Tabs.Screen name="Check-In" component={CheckIn} />
      <Tabs.Screen name="Scoring" component={Scoring} />
    </Tabs.Navigator>
  )
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Auth" component={Login} />
        <Stack.Screen name="Main" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}
