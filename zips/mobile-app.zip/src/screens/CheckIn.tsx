import React, { useEffect, useState } from 'react'
import { View, Text, FlatList, Button, StyleSheet } from 'react-native'
import api from '../api/client'

type Registration = { id:number, tournament:any, player:any, categoryType:string }

export default function CheckIn() {
  const [rows, setRows] = useState<Registration[]>([])
  const [checkedIn, setCheckedIn] = useState<Record<number, boolean>>({})

  const load = async () => {
    const r = await api.get('/registrations'); setRows(r.data)
  }
  useEffect(() => { load() }, [])

  const toggleCheck = (id:number) => setCheckedIn(prev => ({...prev, [id]: !prev[id]}))

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Player Check-In</Text>
      <FlatList
        data={rows}
        keyExtractor={(i)=> String(i.id)}
        renderItem={({item}) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.player?.firstName} {item.player?.lastName}</Text>
            <Text>{item.tournament?.name} • {item.categoryType}</Text>
            <Button title={checkedIn[item.id] ? 'Checked In' : 'Check In'} onPress={() => toggleCheck(item.id)} />
          </View>
        )}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex:1, padding:12 },
  header: { fontSize:20, fontWeight:'600', marginBottom:8 },
  card: { padding:12, borderWidth:1, borderColor:'#ddd', borderRadius:8, marginBottom:10 },
  title: { fontSize:16, fontWeight:'600', marginBottom:4 }
})
