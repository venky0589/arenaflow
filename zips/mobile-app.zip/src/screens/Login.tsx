import React, { useState } from 'react'
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'
import api from '../api/client'

export default function Login({ navigation }: any) {
  const [email, setEmail] = useState('admin@example.com')
  const [password, setPassword] = useState('admin123')
  const [loading, setLoading] = useState(false)

  const login = async () => {
    try {
      setLoading(true)
      const res = await api.post('/auth/login', { email, password })
      await AsyncStorage.setItem('token', res.data.token)
      navigation.replace('Main')
    } catch (e:any) {
      Alert.alert('Login failed', e?.response?.data?.error || 'Check credentials')
    } finally {
      setLoading(false)
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} autoCapitalize="none" />
      <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />
      <Button title={loading ? 'Signing in...' : 'Sign In'} onPress={login} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex:1, alignItems:'center', justifyContent:'center', padding:16 },
  title: { fontSize:24, marginBottom:12 },
  input: { width:'100%', borderWidth:1, borderColor:'#ccc', padding:10, marginBottom:10, borderRadius:6 }
})
