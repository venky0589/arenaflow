import React, { useEffect, useState } from 'react'
import { View, Text, Button, StyleSheet } from 'react-native'
import api from '../api/client'

type Match = { id:number, player1:any, player2:any, score1:number, score2:number, status:string }

export default function Scoring() {
  const [match, setMatch] = useState<Match | null>(null)

  const load = async () => {
    const list = await api.get('/matches')
    setMatch(list.data?.[0] || null)
  }
  useEffect(() => { load() }, [])

  const inc = async (side: 1 | 2) => {
    if (!match) return
    const payload = { ...match, score1: match.score1 || 0, score2: match.score2 || 0 }
    if (side === 1) payload.score1 += 1; else payload.score2 += 1
    await api.put('/matches/' + match.id, payload)
    setMatch(payload)
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Court-side Scoring</Text>
      {match ? (
        <View style={styles.card}>
          <Text style={styles.title}>{match.player1?.firstName} vs {match.player2?.firstName}</Text>
          <Text style={styles.score}>{match.score1 ?? 0} - {match.score2 ?? 0}</Text>
          <View style={styles.row}>
            <Button title="P1 +" onPress={() => inc(1)} />
            <Button title="P2 +" onPress={() => inc(2)} />
          </View>
        </View>
      ) : (
        <Text>No match found</Text>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex:1, padding:12 },
  header: { fontSize:20, fontWeight:'600', marginBottom:8 },
  card: { padding:12, borderWidth:1, borderColor:'#ddd', borderRadius:8, marginBottom:10, alignItems:'center' },
  title: { fontSize:16, fontWeight:'600', marginBottom:4 },
  score: { fontSize:28, fontWeight:'800', marginVertical:8 },
  row: { flexDirection:'row', gap:10 }
})
