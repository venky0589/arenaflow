import React, { useEffect, useState } from 'react'
import { View, Text, FlatList, Button, StyleSheet } from 'react-native'
import api from '../api/client'

type Tournament = { id:number, name:string, location?:string, startDate?:string, endDate?:string }
type Player = { id:number, firstName:string, lastName:string }

export default function Tournaments() {
  const [rows, setRows] = useState<Tournament[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [selectedPlayerId, setSelectedPlayerId] = useState<number | null>(null)

  const load = async () => {
    const ts = await api.get('/tournaments'); setRows(ts.data)
    const ps = await api.get('/players'); setPlayers(ps.data)
    if (ps.data?.length) setSelectedPlayerId(ps.data[0].id)
  }

  useEffect(() => { load() }, [])

  const register = async (t: Tournament) => {
    if (!selectedPlayerId) return
    await api.post('/registrations', { tournament: { id: t.id }, player: { id: selectedPlayerId }, categoryType: 'SINGLES' })
    alert('Registered!')
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Tournaments</Text>
      <FlatList
        data={rows}
        keyExtractor={(item)=> String(item.id)}
        renderItem={({item}) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.name}</Text>
            <Text>{item.location} • {item.startDate} – {item.endDate}</Text>
            <Button title="Register (SINGLES)" onPress={() => register(item)} />
          </View>
        )}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex:1, padding:12 },
  header: { fontSize:20, fontWeight:'600', marginBottom:8 },
  card: { padding:12, borderWidth:1, borderColor:'#ddd', borderRadius:8, marginBottom:10 },
  title: { fontSize:16, fontWeight:'600', marginBottom:4 }
})
